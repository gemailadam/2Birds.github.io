<?php dynamic_sidebar('footer 1'); ?>
<hr>
<?php dynamic_sidebar('footer 2'); ?>
<hr>
<?php dynamic_sidebar('footer 3'); ?>
<hr>

<a href="">&copy;copyright adam <?php echo date('Y') ?> </a>