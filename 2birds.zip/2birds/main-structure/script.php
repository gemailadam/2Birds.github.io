<script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/js/jquery-1.11.3.min.js"></script> 
<script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/js/slideshow.js"></script> 

<?php wp_footer(); ?>